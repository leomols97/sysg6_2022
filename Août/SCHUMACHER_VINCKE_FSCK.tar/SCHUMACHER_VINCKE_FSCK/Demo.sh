#!/bin/bash

C='\033[41m'
E='\033[32m\033[1m'
N='\033[0m'
V='\033[42m'
M='\033[44m'

clear

echo -e "${M}Demarrer${N}"
echo -e "${C}             --> Enter pour continuer${N}"
read
echo

echo -e "${M}La partition : ${N}"
# PARTITION=/dev/sdb2
read PARTITION
echo

umount $PARTITION
umount $PARTITION
echo
echo
echo
echo
echo

echo -e "${M}Nous allons corrompre le système de fichier et le réparer par la suite. ${N}"
echo -e "${M}Pour commencer, créons un système de fichier ext3 dans notre nouvelle partition et ajoutons lui 10 fichier afin de la remplir un peu.${N}"
echo
echo -e "${M}Lancement de : mkfs.ext3 $PARTITION ${N}"
echo -e "${C}             --> Enter pour continuer${N}"
read
mkfs.ext3 $PARTITION
sleep 3
umount $PARTITION
echo

echo -e "${M}Lancement de : mount $PARTITION /mnt ${N}"
echo -e "${C}             --> Enter pour continuer${N}"
read
mount $PARTITION /mnt
echo

echo -e "${M}Lancement de : for i in {1..10}; do echo \"this is file\$i\" > /mnt/file\$i.txt; done ${N}"
echo -e "${C}             --> Enter pour continuer${N}"
read
for i in {1..10}; do echo "this is file$i" > /mnt/file$i.txt; done
echo

echo -e "${M}Rentrons dans le vif du sujet et amusons nous un peu avec une première attaque.${N}"
echo -e "${M}Pour ce faire nous allons corrompre le super block. ${N}"
echo -e "${M}Avec la commande ci-dessous, nous allons écrire des O à l'offset 1024 de la localisation du superblock.${N}"
echo
echo -e "${M}Lancement de : dd if=/dev/zero of=$PARTITION count=1 bs=1024 seek=1${N}"
echo -e "${C}             --> Enter pour continuer${N}"
read
dd if=/dev/zero of=$PARTITION count=1 bs=1024 seek=1
echo

echo -e "${M}Esssayons maintenant de monter le fichier. ${N}"
echo
echo -e "${M}Lancement de : umount /mnt && mount $PARTITION /mnt ${N}"
echo -e "${C}             --> Enter pour continuer${N}"
read
umount /mnt && mount $PARTITION /mnt
echo

# echo -e "${M}Lancement de : fsck $PARTITION ${N}"
# echo -e "${C}             --> Enter pour continuer${N}"
# read
# fsck $PARTITION
# echo

echo -e "${M}C'est un échec ! Mais c'est tout à fait ce que nous voulions.${N}"
echo -e "${M}Pour les cas comme ça, ext3 a des backups du superblock.${N}"
echo -e "${M}Allons voir de plus près l'output de mkfs.ext3 exécuté plus haut. Elle nous renseigne les blocs des superblocs de secours. Prenons par exemple le 2ème.${N}"
echo -e "${M}${N}"
echo -e "${M}Tout ce que nous avons à faire est de dire à mount d'utiliser cette copie du superblock.${N}"
echo -e "${M}mount à besoin d'une adresse, pour ce faire nous allons multiplier l'entrée par 4.${N}"
echo
echo -e "${M}Le backup du superblock  : ${N}"
read BLOCS
BLOCSADRESSE=$((BLOCS * 4))
echo

echo -e "${M}Lancement de : mount -o sb=$BLOCSADRESSE $PARTITION /mnt ${N}"
echo -e "${C}             --> Enter pour continuer${N}"
read
mount -o sb=$BLOCSADRESSE $PARTITION /mnt
echo

# echo -e "${M}Cela à fonctionné, nous pouvons vérifier notre commande avec un simple df.${N}"
# echo
# echo -e "${M}Lancement de : df ${N}"
# echo -e "${C}             --> Enter pour continuer${N}"
# read
# df
# echo

echo -e "${M}Nous lancerons plus tard la commande fsck afin de réparer le superblock que nous venons de corrompre.${N}"
echo
echo -e "${M}Maintenant amusons nous autrement en créant un autre genre de corruption.${N}"
echo -e "${M}Nous allons corrompre ici le système de fichier en faisant pointer le file2.txt sur le contenu du file1.txt.${N}"
echo -e "${M}Vérifions d'abord le conteu de ces fichiers.${N}"
echo

echo -e "${M}Lancement de : cat /mnt/file1.txt /mnt/file2.txt ${N}"
echo -e "${C}             --> Enter pour continuer${N}"
read
cat /mnt/file1.txt /mnt/file2.txt
echo

echo -e "${M}Pour modifier la structure du système de fichier nous allons utiliser la commande debugfs qui est un débogeur pour les systèmes de fichier ext2/3/4. ${N}"
echo -e "${M}Ici, nous allons spécifier quel superblock du système de fichier sera lu par la commande (-s) ainsi que la taille d'un bloc (-b). Nous stipulons aussi que nous voulons ouvrir le système de fichier en R/W (-w).${N}"
echo
echo -e "${M}Lors du lancement de la commande un menu s'ouvrira et plusieurs étapes seront à reproduire afin de corrompre le système de fichier. ${N}"
echo
echo -e "${M}1 : Tout d'abord, nous allons récupérer l'adresse du bloc de données qui contient 'this is file1' avec la commande : stat file1.txt${N}"
echo -e "${M}2 : Il est important de retenir ce que le champ BLOCKS nous renseigne (ex: 2048) et nous pouvons quitter la page stat (pressez q).${N}"
echo
echo -e "${M}Nous allons ensuite modifier le contenu de l'inode du fichier file2.txt et remplacer l'adresse du premier block par l'adresse du premier block de file1.txt.${N}"
echo
echo -e "${M}3 : Pour ce faire tapons : mi file2.txt${N}"
echo -e "${M}4 : Pressons enter jusqu'à arriver à 'Direct Block #0' ${N}"
echo -e "${M}5 : Dès lors nous rentrons la nouvelle adresse comme suit : 'Direct Block #0 [2049] 2048'${N}"
echo -e "${M}6 : Pressons enter jusqu'à sortir du menu${N}"
echo -e "${M}7 : Et quittons debugfs avec : 'quit'${N}"
echo
echo -e "${M}Lancez la commande et veuillez refaire les étapes dans l'ordre svp.${N}"
echo
echo
echo -e "${M}Lancement de : debugfs -s $BLOCS -b 4096 $PARTITION -w ${N}"
echo -e "${C}             --> Enter pour continuer${N}"
read
debugfs -s $BLOCS -b 4096 $PARTITION -w
echo

# stat file1.txt
# mi file2.txt
# quit

echo -e "${M}Démontons et remontons notre système de fichier afin de s'assurer que les changements sont bien écrit sur le disque.${N}"
echo
echo -e "${M}Lancement de : umount /mnt ${N}"
echo -e "${C}             --> Enter pour continuer${N}"
read
umount /mnt
# umount $PARTITION
echo

echo -e "${M}Lancement de : mount -o sb=$BLOCSADRESSE $PARTITION /mnt -t ext3 ${N}"
echo -e "${C}             --> Enter pour continuer${N}"
read
mount -o sb=$BLOCSADRESSE $PARTITION /mnt -t ext3
echo

echo -e "${M}Vérifions maintenant le contenu des fichiers file1 et file2.${N}"
echo
echo -e "${M}Lancement de : cat /mnt/file1.txt /mnt/file2.txt ${N}"
echo -e "${C}             --> Enter pour continuer${N}"
read
cat /mnt/file1.txt /mnt/file2.txt
echo
echo -e "${M}Nous pouvons voir que les 2 fichiers ont maintenant le même contenu.${N}"
echo

echo -e "${M}Réparons maintenant tout ça avec la commande fsck mais il faut d'abord démonter le système de fichier.${N}"
echo
echo -e "${M}Lancement de : umount /mnt ${N}"
echo -e "${C}             --> Enter pour continuer${N}"
read
umount /mnt
echo

echo -e "${M}Lors du lancement de fsck, répondons 'oui' à tous les questions de modifications que va apporter fsck. Nous reviendrons dessus après le lancement de la commande.${N}"
echo -e "${M}Lancement de : fsck $PARTITION ${N}"
echo -e "${C}             --> Enter pour continuer${N}"
read
fsck $PARTITION
echo

echo -e "${M}Tout d'abord à la deuxième ligne nous pouvons voir que fsck a détecter que le premier superblock a été corrompu. Il a dès lors utilisé le superblock suivant qui est un des superblock de back-up.${N}"
echo
echo -e "${M}Ensuite nous remarquons que fsck passe par les différentes phases de check. La commande bloque sur une erreur de 'Multiply-claimed block'. En effet, c'est nous qui l'avons provoqué.${N}"
echo -e "${M}Fsck va proposer de cloner les blocks afin de réparer l'erreur. Cette réparation va cloner le block afin que chaque fichier est le sien et que si l'un modifie les données, le second n'est pas modifié.${N}"
echo -e "${M}Fsck va ensuite réparer un nombre d'incohérence qu'il a pu détecter notament sur le nombre d'inodes et de blocs libres réellement disponible.${N}"
echo
