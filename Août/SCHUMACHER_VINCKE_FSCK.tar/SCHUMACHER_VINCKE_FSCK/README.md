# Projet SYSG6 - fsck

## Informations

Projet dans le cadre du cours de SYSG6 2021/2022 avec MBA. Il traite de l'outil fsck, permettant de vérifier et réparer un système de fichier incohérent.

## Auteurs

SCHUMACHER VINCKE Jan (53135)

## Génération du rapport

Après avoir décompressé l'archive : 

- Au sein d'un terminal, se rendre dans le dossier :  **SCHUMACHER_VINCKE_FSCK**.
- Un fichier **Makefile** y existe, permettant d'exécuter la commande suivante :

```bash
# Permet de générer le rapport dans le dossier courant
make rapport 
```

Elle nécessite la présence du programme **pdflatex**.

La commande génère un rapport au format .pdf dans le dossier courant.

Le nom du fichier généré est **SCHUMACHER_VINCKE_FSCK_RAPPORT.pdf**.

## Lacement de la démonstration

**ATTENTION !!!** Avant de lancer la démonstration il est important d'avoir une partition dont le risque de la perte des données ne nous dérange pas. Nous allons corrompre un système de fichier et par la suite le vérifier et réparer avec fsck. Ces actions ont de gros risque de perte de données si elles sont mal effectuées. Pour le bon fonctionnement je vous conseille donc,de créer sur une clé USB, une nouvelle partition (fdisk) sans aucun système de fichier. De plus, la démonstration à besoin des droits sudo pour fonctionner correctement, il est important de rentrer la commande "su" et de rentrer le mdp sudo avant de lancer la démonstration. Dès lors, depuis le dossier du projet vous pouvez lancer le bash avec la commande suivante :

```bash
# Permet de lancer le script bash
bash Demo.sh
```

Dès le départ, le script vous demandera la partition que vous voulez utiliser pour la démonstration (ex: /dev/sdb2). **ATTENTION** Il ne faut pas se tromper de partition ! Rentrez bien la partition dont les données peuvent être écrasée ou la partition nouvellement créée.



