Présentation de fork(), vfork() & clone() par Léopold Mols
==========================================================

Rendez-vous dans le dossier nommé "MOLS_FORK_VFORK_CLONE" via un terminal


Pour regénérer un fichier ;pff depuis le fichier LaTex
====================================================

1) Rendez-vous dans le dossier nommé "Documents" via une fenêtre de terminal
2) Entrez et exécutez la commande "pdflatex MOLS_FORK_VFORK_CLONE.tex" pour générer un fichier nommé de la même manière qu'est nommé le fichier .tex
3) Suivez les instructions jusqu'à la fin de l'exécution de la génération du fichier .pdf
4) Vous trouverez le fichier .pdf dans le dossier dans lequel vous l'aurez spécifié lors de l'exécution de la génération du fichier .pdf


Pour compiler les codes
=======================

1) Rendez-vous dans le dossier contenant les codes dans un fichier .c
2) Entrez et exécutez la commande "make nomDuFichier.c"
3) Si la commande ne s'exécute pas correctement, entrez la commande "gcc -Wall nomDuFichier.c -o nomDuFichier"
4) Exécutez le fichier objet en entrant et exécutant le fichier "./nomDuFichier"